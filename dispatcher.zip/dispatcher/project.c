#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>

typedef struct node {
    char* message;
    char* dep;
    struct node * next;

} node;

node* CreateNode(node* head ,char* message,char* dep)
{
    node* headTemp = (node*)malloc(sizeof(node));
	if (NULL == headTemp)
	{
		printf ("error in memory allocation\n");
		return NULL;
	}
    headTemp->message=message;
    headTemp->dep=dep;
    headTemp->next=head;
    return headTemp;

	//message= callto ();
	//printf ("%s",message);
}

node* MoveFromToDoToDoing(node* headSource, node* headDestination)
{
	node* runner = headSource;
	
	if (runner->next == NULL)
	{
		runner->next = headDestination;
	}
	
	return headSource;
}

//the function delets the last node of the fi
node* DeleteLastNode(node* head)
{
	node* prev= head; 
	node* last=prev->next; 
	
	if (prev->next==NULL) //node is the last element in the linked list
	{
		return prev; //release the lest node
	}
	
	//there are more elements before the last element in the linked list
	
	
	while(last->next!=NULL)
	{
		prev=prev->next; //previous
		last=last->next; //current
	}
	
	prev->next=NULL; //disconnects the last node form the first linked list
	return last;
	
}

void print_list (node *head)
{
	node *current= head;
	while (current!=NULL) {
		printf ("%s\n",current->message);
		printf ("%s\n",current->dep);
		current=current->next;
	}
}

/*
char* callto ()
{
	char * dep;
	int r=0;
	
	r= (rand()%4); //0-3
	
	switch (r)
	{
		case 0:
		dep= "Police";
		break;
		case 1:
		dep= "Fire";
		break;
		case 2:
		dep= "Ambulance";
		break;
		case 3:
		dep= "City";
		break;

	}


return dep;
}

char* message()
{
	char* message;
	int m=0;

	m= (rand()%10); //0-9
	
	switch (m)
	{
		case 0:
		message= "Help me!";
		break;
		case 1:
		message= "Help me ASAP!";
		break;
		case 2:
		message= "Fire!";
		break;
		case 3:
		message= "Hurricane";
		break;
		case 4:
		message= "Plumbing Issues";
		break;
		case 5:
		message= "I need help";
		break;
		case 6:
		message= "Hurricane";
		break;
		case 7:
		message= "I lost my hat and my umbrella";
		break;
		case 8:
		message= "I got lost";
		break;
		case 9:
		message= "earthquake";
		break;
		
		
	}
	


return message;
	

	
	
}
*/

int main (void) 
{
	                     /*       list1= todo list                */                    
	node* head1 = NULL;
	node* head2=NULL;
	char* dep; //call to
	char* mes;
	
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
		dep= callto();
		mes=message();
		head1=CreateNode(head1,mes,dep); //queue , the first element inserted is the first that comes out.
	
	
	
	
	/*                              list2 : doing list                                     */
	
	head2= MoveFromToDoToDoing(head1,head2);
	//head2=CreateNode(head1,"hello","hello"); //queue , the first element inserted is the first that comes out.
	
	


printf ("the first list is:\n"); //todo list
print_list (head1);

printf ("the second list is:\n"); //doing list
print_list (head2);



free (head2); //deletes the second list
head2=NULL; // no address.



return 0;

}
